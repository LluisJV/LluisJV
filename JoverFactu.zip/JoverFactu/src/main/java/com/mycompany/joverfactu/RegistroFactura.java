/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.joverfactu;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 *
 * @author lluis
 */
public class RegistroFactura {

    JSONParser parser;
    FileReader fr;
    FileWriter fw;

    JSONArray datosfactura;
    JSONObject objfactura;
    Integer idmax;
    
    String path = "data/facturas/registro_facturas.json";

    RegistroFactura() {

        try {
            parser = new JSONParser();
            fr = new FileReader(path);
            datosfactura = (JSONArray) parser.parse(fr);

        } catch (IOException e) {
            System.out.println("Archivo json no encontrado");

        } catch (ParseException ex) {
            System.out.println("Imposible hacer el parse");
        }

    }

    public void readJson() {

        try {

            JSONObject numero = (JSONObject) datosfactura.get(datosfactura.size() - 1);
            idmax = Integer.parseInt(numero.get("id").toString());
        } catch (IndexOutOfBoundsException e) {
            idmax = 0;
            System.out.println("outofbounds");

        }

    }

    public void writeJson(String nombredoc, String fecha, String total, String cliente, String NIF, String direccion, String direccionpostal, JSONArray productos) {
        objfactura = new JSONObject();

        objfactura.put("nombredoc", nombredoc);
        objfactura.put("fecha", fecha);
        objfactura.put("total", total);
        objfactura.put("cliente", cliente);
        objfactura.put("NIF", NIF);
        objfactura.put("direccion", direccion);
        objfactura.put("direccionpostal", direccionpostal);
        objfactura.put("productos", productos);
        objfactura.put("id", idmax);
        
        
        /*System.out.println("nombredoc: " + nombredoc);
        System.out.println("fecha: " + fecha);
        System.out.println("total: " + total);
        System.out.println("cliente: " + cliente);
        System.out.println("NIF: " + NIF);
        System.out.println("direccion: " + direccion);
        System.out.println("direccionpostal: " + direccionpostal);
        System.out.println("productos: " + productos);
        System.out.println("id: " + idmax);*/

        datosfactura.add(objfactura);
        this.idmax++;

    }

    public void save() {

        try {
            fw = new FileWriter(path, false);
            fw.write(datosfactura.toJSONString());//guardamos en el archivo la cadena tipo json
            fw.close();

        } catch (IOException e) {
            System.out.println("No se ha podido guardad, archivo no encontrado");

        }

    }

    public int[] buscar(String campo) {
        JSONObject json = new JSONObject();
        int[] indices = new int[datosfactura.size() + 1];
        int contador = 0;

        for (int i = 0; i < datosfactura.size(); i++) {
            json = (JSONObject) datosfactura.get(i);

            if (empiezaPor(campo, json.get("nombre").toString())) {

                indices[contador] = i;
                contador++;

            }

        }

        indices[contador] = -1; //centinela

        return indices; //no va a haber el incide -1 en el array
    }

    public boolean empiezaPor(String inicio, String name) {

        if (inicio == "") {   //buscador
            return true;

        }

        if (inicio.length() > name.length()) {
            return false;
        }

        for (int i = 0; i < inicio.length(); ++i) {
            if (inicio.charAt(i) != name.charAt(i)) {
                return false;
            }
        }
        return true;
    }

    public boolean indicevalido(String id) {
        Integer i = Integer.parseInt(id);

        return i <= idmax && i >= 1;

    }

}
