/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.joverfactu;

import com.itextpdf.io.image.ImageData;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.color.Color;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.border.Border;
import com.itextpdf.layout.border.DashedBorder;
import com.itextpdf.layout.border.SolidBorder;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.property.TextAlignment;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 *
 * @author lluis
 */
public class Factura {

    private String nombre, nombrecliente, direccioncliente, codigopostalcliente, id; //datos factura
    private JSONArray productos, datosfactura;
    private JSONObject datosempresa;

    Fecha fecha;
    String date;

    Factura(JSONArray productos) {
        try {
            for(int i = 0; i < productos.size(); i++){  //copiamos productos de la factura
                this.productos.add((JSONObject) productos.get(i));
            
            } 

            //lectura datos factura a generar
            JSONParser parser = new JSONParser();
            FileReader filereader = new FileReader("data/registro_facturas.json");
            datosfactura = (JSONArray) parser.parse(filereader);

        } catch (IOException e) {
            System.out.println("Archivo no encontrado");

        } catch (ParseException ex) {
            System.out.println("Imposible parsear json");
        }

    }

    public void datoscliente() {
        fecha = new Fecha();

        date = fecha.getFecha();

        //datos cliente y factura
        JSONObject facturadata = (JSONObject) datosfactura.get(datosfactura.size()); //leemos ultimo objeto de la factura

        nombre = facturadata.get("nombre").toString();
        direccioncliente = facturadata.get("direccioncliente").toString();
        codigopostalcliente = facturadata.get("codigopostalcliente").toString();
        id = facturadata.get("id").toString();
        nombrecliente = facturadata.get("nombrecliente").toString();
        
        
        
    }

    public void generar() {

        String path = "data/facturas/" + nombre + "_" + id + ".pdf";

        try {
            PdfWriter pdfWriter = new PdfWriter(path);
            PdfDocument pdfDocument = new PdfDocument(pdfWriter);
            pdfDocument.setDefaultPageSize(PageSize.A4);

            Document document = new Document(pdfDocument);

            //tamaño columnas header
            float twocol = 285f;
            float threecol = 190f;
            float threeColumnWidth[] = {threecol, threecol, threecol};

            float twocol150 = twocol + 150f;
            float twocolumnWidth[] = {twocol150, twocol}; //columna de dos elementos

            float fullwidth[] = {threecol * 3};

            Paragraph onesp = new Paragraph("\n");

            Table table = new Table(twocolumnWidth);

            table.addCell(getCell14LEFT(nombre, true));

            Table nestedtable = new Table(new float[]{twocol / 2, twocol / 2});

            nestedtable.addCell(getHeaderTextCell("Numero de factura: ", true));
            nestedtable.addCell(getHeaderTextCellValue(id, false));
            nestedtable.addCell(getHeaderTextCell("Fecha: ", true));
            nestedtable.addCell(getHeaderTextCellValue(date, false));

            table.addCell(new Cell().add(nestedtable).setBorder(Border.NO_BORDER));

            Border gb = new SolidBorder(Color.GRAY, 1f);

            Table divider = new Table(fullwidth);

            divider.setBorder(gb);

            //add elements
            document.add(table);

            //document.add(onesp); //salto de linea

            document.add(divider);

            //document.add(onesp);

            Table twoColTable = new Table(twocolumnWidth);

            twoColTable.addCell(getBillingShipping(nombre));
            twoColTable.addCell(getBillingShipping("Cliente: "));
            document.add(twoColTable.setMarginBottom(12f));

            Table twoColTable2 = new Table(twocolumnWidth);

            twoColTable2.addCell(getCell14LEFT("Frutas Jover  ", true));
            twoColTable2.addCell(getCell10LEFT("direccion", true));
            twoColTable2.addCell(getCell10LEFT("codigopostal", true));
            twoColTable2.addCell(getCell10LEFT("tel1", false));
            twoColTable2.addCell(getCell10LEFT("tel1", false));
            twoColTable2.addCell(getCell10LEFT("mail", false));
            twoColTable2.addCell(getCell10LEFT("mail", false));
            twoColTable2.addCell(getCell10LEFT("mail", false));
            twoColTable2.addCell(getCell10LEFT("web", false));
            document.add(twoColTable2);

            Table twoColTable3 = new Table(twocolumnWidth);

            twoColTable3.addCell(getCell14LEFT(nombrecliente, true));
            twoColTable3.addCell(getCell10LEFT(direccioncliente, true));
            twoColTable3.addCell(getCell10LEFT(codigopostalcliente, false));
            twoColTable3.addCell(getCell10LEFT("ILLES BALEARS", false));
            document.add(twoColTable3);

            float oneColumnwidth[] = {twocol150};

            Table oneColTable1 = new Table(oneColumnwidth);

            /*oneColTable1.addCell(getCell10LEFT("Name", true));
            oneColTable1.addCell(getCell10LEFT("Address", true));
            oneColTable1.addCell(getCell10LEFT("Lorem ipsum", false));
            oneColTable1.addCell(getCell10LEFT("Carretera Caramiuxa KM 0,5", false));
            document.add(oneColTable1.setMarginBottom(10f));*/

            Table tableDivider2 = new Table(fullwidth);

            Border dgb = new DashedBorder(Color.GRAY, 1 / 2f);

            document.add(tableDivider2.setBorder(dgb));

            Paragraph productPara = new Paragraph("Products");

            document.add(productPara.setBold());
            Table threeColTable1 = new Table(threeColumnWidth);

            threeColTable1.setBackgroundColor(Color.BLACK, 0.7f);

            threeColTable1.addCell(new Cell().add("Nombre").setBold().setFontColor(Color.WHITE).setBorder(Border.NO_BORDER).setTextAlignment(TextAlignment.LEFT));
            threeColTable1.addCell(new Cell().add("Cantidad").setBold().setFontColor(Color.WHITE).setBorder(Border.NO_BORDER).setTextAlignment(TextAlignment.CENTER));
            threeColTable1.addCell(new Cell().add("Precio").setBold().setFontColor(Color.WHITE).setBorder(Border.NO_BORDER).setMarginRight(15f).setTextAlignment(TextAlignment.RIGHT));
            document.add(threeColTable1);

            List<Product> productList = new ArrayList<>();

            productList.add(new Product("manzana", 2, 2));
            productList.add(new Product("platano", 23, 2));
            productList.add( new Product("pera", 2, 24));
            productList.add( new Product("pera", 2, 24));
            productList.add( new Product("pera", 2, 24));
            productList.add(new Product("higo", 27, 2));
            productList.add(new Product("melon", 52, 2));
            productList.add(new Product("naranja", 321, 2));

            productList.add(new Product("higo", 27, 2));
            productList.add(new Product("melon", 52, 2));
            productList.add(new Product("naranja", 321, 2));
            productList.add( new Product("pera", 2, 24));
            productList.add( new Product("pera", 2, 24));
            productList.add(new Product("higo", 27, 2));
            productList.add(new Product("melon", 52, 2));
            productList.add(new Product("naranja", 321, 2));

            Table threeColTable2 = new Table(threeColumnWidth);

            float totalSum = 0f;

            for (Product product : productList) {

                float total = product.getCantidad() * product.getPrecio();
                totalSum += total;

                threeColTable2.addCell(new Cell().add(product.getPname()).setBorder(Border.NO_BORDER).setMarginLeft(10f));
                threeColTable2.addCell(new Cell().add(String.valueOf(product.getCantidad())).setTextAlignment(TextAlignment.CENTER).setBorder(Border.NO_BORDER));
                threeColTable2.addCell(new Cell().add(String.valueOf(total)).setTextAlignment(TextAlignment.RIGHT).setBorder(Border.NO_BORDER).setMarginRight(15f));

            }

            document.add(threeColTable2.setMarginBottom(20f));

            float onetwo[] = {threecol + 125f, threecol * 2};
            Table threeColTable4 = new Table(onetwo);

            threeColTable4.addCell(
                    new Cell().add("").setBorder(Border.NO_BORDER));
            threeColTable4.addCell(
                    new Cell().add(tableDivider2).setBorder(Border.NO_BORDER));
            document.add(threeColTable4);

            Table threeColTable3 = new Table(threeColumnWidth);

            threeColTable3.addCell(
                    new Cell().add("").setBorder(Border.NO_BORDER).setMarginLeft(10f));
            threeColTable3.addCell(
                    new Cell().add("Total").setTextAlignment(TextAlignment.CENTER).setBorder(Border.NO_BORDER));
            threeColTable3.addCell(
                    new Cell().add(String.valueOf(totalSum) + " €").setTextAlignment(TextAlignment.RIGHT).setBorder(Border.NO_BORDER));

            document.add(threeColTable3);

            document.add(tableDivider2);

            document.add(
                    new Paragraph("\n"));
            document.add(divider.setBorder(new SolidBorder(Color.GRAY, 1)).setMarginBottom(15f));

            //close
            document.close();

            System.out.println(
                    "PDF generated!!!");
        } catch (IOException e) {
            e.printStackTrace();

        }

    }

    static Cell getHeaderTextCell(String textValue, boolean bold) {
        if (bold) {
            return new Cell().add(textValue).setBold().setBorder(Border.NO_BORDER).setTextAlignment(TextAlignment.RIGHT);
        } else {
            return new Cell().add(textValue).setBorder(Border.NO_BORDER).setTextAlignment(TextAlignment.RIGHT);

        }

    }

    static Cell getHeaderTextCellValue(String textValue, boolean bold) {
        
        if (bold) {
            return new Cell().add(textValue).setBold().setBorder(Border.NO_BORDER).setTextAlignment(TextAlignment.LEFT);
        } else {
            return new Cell().add(textValue).setBorder(Border.NO_BORDER).setTextAlignment(TextAlignment.LEFT);

        }
        
    }

    static Cell getBillingShipping(String textValue) {
        return new Cell().add(textValue).setFontSize(12f).setBold().setBorder(Border.NO_BORDER).setTextAlignment(TextAlignment.LEFT);

    }

    static Cell getCell14LEFT(String textValue, boolean isBold) {
        Cell myCell = new Cell().add(textValue).setFontSize(14f).setBorder(Border.NO_BORDER).setTextAlignment(TextAlignment.LEFT);

        return isBold ? myCell.setBold() : myCell;
    }

    static Cell getCell10LEFT(String textValue, boolean isBold) {
        Cell myCell = new Cell().add(textValue).setFontSize(10f).setBorder(Border.NO_BORDER).setTextAlignment(TextAlignment.LEFT);

        return isBold ? myCell.setBold() : myCell;
    }

    public void openpdf() {

    }

    static class Product {

        private String pname;
        private int cantidad;
        private float precio;

        public Product(String name, int cantidad, float precio) {

            this.pname = name;
            this.cantidad = cantidad;
            this.precio = precio;

        }

        public String getPname() {
            return pname;
        }

        public int getCantidad() {
            return cantidad;
        }

        public float getPrecio() {
            return precio;
        }

        public void setPname(String pname) {
            this.pname = pname;
        }

        public void setCantidad(int cantidad) {
            this.cantidad = cantidad;
        }

        public void setPrecio(float precio) {
            this.precio = precio;
        }

    }

}
