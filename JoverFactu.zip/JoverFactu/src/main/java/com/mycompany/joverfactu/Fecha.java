/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.joverfactu;

import java.time.LocalDate;
/**
 *
 * @author lluis
 */
public class Fecha {
    LocalDate myObj;
    
    Fecha(){
        myObj = LocalDate.now();
        
    
    }
    
    public String getFecha(){
        return myObj.toString();
    
    
    }
    
}
