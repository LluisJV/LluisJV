/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.joverfactu;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 *
 * @author lluis
 */
public class Registro {

    JSONParser parser;
    FileReader fr;
    FileWriter fw;

    JSONArray jsonarray;
    JSONArray jsonarray3;
    JSONObject obj;
    Integer idmax;

    Registro(String path) {

        try {
            parser = new JSONParser();
            fr = new FileReader(path);
            jsonarray = (JSONArray) parser.parse(fr);
            jsonarray3 = new JSONArray();
            jsonarray3.addAll(jsonarray);

        } catch (IOException e) {
            System.out.println("Archivo json no encontrado");

        } catch (ParseException ex) {
            System.out.println("Imposible hacer el parse");
        }

    }
    
    public void leer(String path){
        try{
        fr = new FileReader(path);
        jsonarray = (JSONArray) parser.parse(fr);
        }catch(IOException e){
            System.out.println("Archivo json no encontrado");
        } catch (ParseException ex) {
            System.out.println("Imposible hacer el parse");
        }
    
    
    
    }

    public void readJson() {

        try {

            JSONObject numero = (JSONObject) jsonarray.get(jsonarray.size() - 1);
            idmax = Integer.parseInt(numero.get("id").toString());
        } catch (IndexOutOfBoundsException e) {
            idmax = 0;
            System.out.println("outofbounds");

        }

    }

    public void writeJson(String precio, String kg, String nombre, int id) {
        obj = new JSONObject();

        obj.put("id", id);
        obj.put("nombre", nombre);
        obj.put("precio", precio);
        obj.put("kg", kg);
        obj.put("cantidad", 0);
        obj.put("cajas", 0);

        jsonarray.add(obj);
        jsonarray3.add(obj);
        this.idmax++;

    }

    public void save(String path) {

        try {
            fw = new FileWriter(path, false);
            fw.write(jsonarray.toJSONString());//guardamos en el archivo la cadena tipo json
            fw.close();

        } catch (IOException e) {
            System.out.println("No se ha podido guardad, archivo no encontrado");

        }

    }

    public int[] buscar(String campo, JSONArray arraybusqueda) {
        JSONObject json = new JSONObject();
        int[] indices = new int[arraybusqueda.size() + 1];
        int contador = 0;

        for (int i = 0; i < arraybusqueda.size(); i++) {
            json = (JSONObject) arraybusqueda.get(i);

            if (empiezaPor(campo, json.get("nombre").toString())) {

                indices[contador] = Integer.parseInt(json.get("id").toString());
                contador++;

            }

        }

        indices[contador] = -1; //centinela

        return indices; //no va a haber el incide -1 en el array
    }

    public boolean empiezaPor(String inicio, String name) {

        if (inicio == "") {   //buscador
            return true;

        }

        if (inicio.length() > name.length()) {
            return false;
        }

        for (int i = 0; i < inicio.length(); ++i) {
            if (inicio.charAt(i) != name.charAt(i)) {
                return false;
            }
        }
        return true;
    }

    public void actualizarelementotabla(String id, String nombre, String precio) {
        for (int elemento = 0; elemento < jsonarray.size(); elemento++) {
            JSONObject obj = new JSONObject();

            obj = (JSONObject) jsonarray.get(elemento);

            if (Integer.parseInt(obj.get("id").toString()) == Integer.parseInt(id)) {
                obj.replace("nombre", nombre);
                obj.replace("precio", precio);
                jsonarray.remove(id);
                break;

                //jsonarray.
            }

        }

        JSONArray newarray = new JSONArray();

        for (int i = 0; i < jsonarray.size(); i++) {
            JSONObject iterador = (JSONObject) jsonarray.get(i);

            if (iterador.get("id").toString() == id) {
                newarray.add(obj);

            } else {
                newarray.add(iterador);
            }

        }

        jsonarray = newarray;

    }

    public JSONObject getElemento(String id, JSONArray arraybusqueda) {
        JSONObject obj = new JSONObject();

        for (int i = 0; i < arraybusqueda.size(); i++) {
            obj = (JSONObject) arraybusqueda.get(i);
            
            if (Integer.parseInt(obj.get("id").toString()) == Integer.parseInt(id)) {
                return obj;
            }

        }
        
        return obj;
    }

    public boolean indicevalido(String id) {
        Integer i = Integer.parseInt(id);

        return i <= idmax && i >= 1;

    }

}
